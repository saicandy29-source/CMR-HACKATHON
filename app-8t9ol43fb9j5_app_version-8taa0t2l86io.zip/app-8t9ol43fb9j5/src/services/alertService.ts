// Alert Service for managing emergency alerts using localStorage and CustomEvent API
import type { Alert, AlertPriority, AlertStatus } from '@/types/safety';

const STORAGE_KEY = 'women_safety_alerts';
const ALERT_EVENT = 'safety_alert_update';
const PTT_EVENT = 'ptt_status_update';

class AlertService {
  // Get all alerts from localStorage
  getAlerts(): Alert[] {
    try {
      const data = localStorage.getItem(STORAGE_KEY);
      return data ? JSON.parse(data) : [];
    } catch (error) {
      console.error('Error reading alerts:', error);
      return [];
    }
  }

  // Save alerts to localStorage
  private saveAlerts(alerts: Alert[]): void {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(alerts));
      this.dispatchAlertEvent();
    } catch (error) {
      console.error('Error saving alerts:', error);
    }
  }

  // Create a new emergency alert
  createAlert(poleId: string, location: string, zone?: string): Alert {
    const newAlert: Alert = {
      id: `alert_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      poleId,
      location,
      timestamp: new Date().toISOString(),
      priority: 'high',
      status: 'active',
      zone: zone || 'Zone A',
      voiceChannelActive: false,
    };

    const alerts = this.getAlerts();
    alerts.unshift(newAlert); // Add to beginning
    this.saveAlerts(alerts);

    return newAlert;
  }

  // Update alert status
  updateAlertStatus(alertId: string, status: AlertStatus): void {
    const alerts = this.getAlerts();
    const alert = alerts.find(a => a.id === alertId);
    
    if (alert) {
      alert.status = status;
      if (status === 'resolved') {
        alert.resolvedAt = new Date().toISOString();
      }
      this.saveAlerts(alerts);
    }
  }

  // Update alert priority
  updateAlertPriority(alertId: string, priority: AlertPriority): void {
    const alerts = this.getAlerts();
    const alert = alerts.find(a => a.id === alertId);
    
    if (alert) {
      alert.priority = priority;
      this.saveAlerts(alerts);
    }
  }

  // Notify authorities
  notifyAuthority(alertId: string, authority: string): void {
    const alerts = this.getAlerts();
    const alert = alerts.find(a => a.id === alertId);
    
    if (alert) {
      if (!alert.notifiedAuthorities) {
        alert.notifiedAuthorities = [];
      }
      if (!alert.notifiedAuthorities.includes(authority)) {
        alert.notifiedAuthorities.push(authority);
        alert.status = 'notified';
        this.saveAlerts(alerts);
      }
    }
  }

  // Get active alerts
  getActiveAlerts(): Alert[] {
    return this.getAlerts().filter(a => a.status === 'active' || a.status === 'notified');
  }

  // Get alerts by zone
  getAlertsByZone(zone: string): Alert[] {
    return this.getAlerts().filter(a => a.zone === zone);
  }

  // Get alert aggregation by zones
  getAlertAggregation() {
    const alerts = this.getActiveAlerts();
    const zones = new Map<string, Alert[]>();

    alerts.forEach(alert => {
      const zone = alert.zone || 'Unknown';
      if (!zones.has(zone)) {
        zones.set(zone, []);
      }
      zones.get(zone)?.push(alert);
    });

    return Array.from(zones.entries()).map(([zone, zoneAlerts]) => ({
      zone,
      count: zoneAlerts.length,
      alerts: zoneAlerts,
    }));
  }

  // Enable/disable voice channel for an alert
  toggleVoiceChannel(alertId: string, active: boolean): void {
    const alerts = this.getAlerts();
    const alert = alerts.find(a => a.id === alertId);
    
    if (alert) {
      alert.voiceChannelActive = active;
      this.saveAlerts(alerts);
      this.dispatchPTTEvent(alert.poleId, active);
    }
  }

  // Dispatch custom event for real-time updates
  private dispatchAlertEvent(): void {
    window.dispatchEvent(new CustomEvent(ALERT_EVENT, {
      detail: { alerts: this.getAlerts() }
    }));
  }

  // Dispatch PTT event
  private dispatchPTTEvent(poleId: string, active: boolean): void {
    window.dispatchEvent(new CustomEvent(PTT_EVENT, {
      detail: { poleId, active }
    }));
  }

  // Subscribe to alert updates
  subscribeToAlerts(callback: (alerts: Alert[]) => void): () => void {
    const handler = (event: Event) => {
      const customEvent = event as CustomEvent;
      callback(customEvent.detail.alerts);
    };

    window.addEventListener(ALERT_EVENT, handler);
    
    // Return unsubscribe function
    return () => window.removeEventListener(ALERT_EVENT, handler);
  }

  // Subscribe to PTT updates
  subscribeToPTT(callback: (poleId: string, active: boolean) => void): () => void {
    const handler = (event: Event) => {
      const customEvent = event as CustomEvent;
      callback(customEvent.detail.poleId, customEvent.detail.active);
    };

    window.addEventListener(PTT_EVENT, handler);
    
    // Return unsubscribe function
    return () => window.removeEventListener(PTT_EVENT, handler);
  }

  // Clear all alerts (for testing)
  clearAllAlerts(): void {
    localStorage.removeItem(STORAGE_KEY);
    this.dispatchAlertEvent();
  }
}

// Export singleton instance
export const alertService = new AlertService();
