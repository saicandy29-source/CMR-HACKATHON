// Pole Service for managing safety poles and LoRa gateway operations
import type { Pole, LoRaGateway, LoRaMessage, PoleStatusType, LoRaSignalStrength } from '@/types/safety';

const POLES_STORAGE_KEY = 'women_safety_poles';
const GATEWAYS_STORAGE_KEY = 'women_safety_gateways';
const LORA_MESSAGES_KEY = 'women_safety_lora_messages';
const POLE_UPDATE_EVENT = 'pole_update';
const GATEWAY_UPDATE_EVENT = 'gateway_update';
const LORA_MESSAGE_EVENT = 'lora_message';

class PoleService {
  // Initialize with sample data if empty
  constructor() {
    if (this.getPoles().length === 0) {
      this.initializeSampleData();
    }
  }

  // Initialize sample poles and gateway
  private initializeSampleData(): void {
    const samplePoles: Pole[] = [
      {
        id: 'pole_1',
        poleId: 'POLE-001',
        location: 'Campus North Gate, Building A',
        zone: 'Zone A',
        latitude: 40.7128,
        longitude: -74.0060,
        status: 'online',
        loraDeviceId: 'LORA-DEV-001',
        loraFrequency: '868.1 MHz',
        signalStrength: 'excellent',
        batteryLevel: 95,
        lastHeartbeat: new Date().toISOString(),
        installationDate: '2026-01-01',
        notes: 'Main entrance pole'
      },
      {
        id: 'pole_2',
        poleId: 'POLE-002',
        location: 'Campus Library, East Wing',
        zone: 'Zone A',
        latitude: 40.7138,
        longitude: -74.0070,
        status: 'online',
        loraDeviceId: 'LORA-DEV-002',
        loraFrequency: '868.3 MHz',
        signalStrength: 'good',
        batteryLevel: 87,
        lastHeartbeat: new Date().toISOString(),
        installationDate: '2026-01-01',
        notes: 'Library area coverage'
      },
      {
        id: 'pole_3',
        poleId: 'POLE-003',
        location: 'Campus Parking Lot B',
        zone: 'Zone B',
        latitude: 40.7148,
        longitude: -74.0080,
        status: 'online',
        loraDeviceId: 'LORA-DEV-003',
        loraFrequency: '868.5 MHz',
        signalStrength: 'fair',
        batteryLevel: 72,
        lastHeartbeat: new Date().toISOString(),
        installationDate: '2026-01-02',
        notes: 'Parking area monitoring'
      }
    ];

    const sampleGateway: LoRaGateway = {
      id: 'gateway_1',
      gatewayId: 'GATEWAY-001',
      name: 'Main Campus Gateway',
      location: 'Central Administration Building',
      status: 'active',
      connectedPoles: 3,
      signalRange: 2000,
      lastUpdate: new Date().toISOString()
    };

    localStorage.setItem(POLES_STORAGE_KEY, JSON.stringify(samplePoles));
    localStorage.setItem(GATEWAYS_STORAGE_KEY, JSON.stringify([sampleGateway]));
    this.dispatchPoleEvent();
    this.dispatchGatewayEvent();
  }

  // Get all poles
  getPoles(): Pole[] {
    try {
      const data = localStorage.getItem(POLES_STORAGE_KEY);
      return data ? JSON.parse(data) : [];
    } catch (error) {
      console.error('Error reading poles:', error);
      return [];
    }
  }

  // Get pole by ID
  getPoleById(poleId: string): Pole | null {
    const poles = this.getPoles();
    return poles.find(p => p.poleId === poleId) || null;
  }

  // Get poles by zone
  getPolesByZone(zone: string): Pole[] {
    return this.getPoles().filter(p => p.zone === zone);
  }

  // Get poles by status
  getPolesByStatus(status: PoleStatusType): Pole[] {
    return this.getPoles().filter(p => p.status === status);
  }

  // Save poles to localStorage
  private savePoles(poles: Pole[]): void {
    try {
      localStorage.setItem(POLES_STORAGE_KEY, JSON.stringify(poles));
      this.dispatchPoleEvent();
    } catch (error) {
      console.error('Error saving poles:', error);
    }
  }

  // Create new pole
  createPole(poleData: Omit<Pole, 'id' | 'lastHeartbeat'>): Pole {
    const newPole: Pole = {
      ...poleData,
      id: `pole_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      lastHeartbeat: new Date().toISOString(),
    };

    const poles = this.getPoles();
    poles.push(newPole);
    this.savePoles(poles);

    return newPole;
  }

  // Update pole
  updatePole(poleId: string, updates: Partial<Pole>): void {
    const poles = this.getPoles();
    const poleIndex = poles.findIndex(p => p.poleId === poleId);

    if (poleIndex !== -1) {
      poles[poleIndex] = { ...poles[poleIndex], ...updates };
      this.savePoles(poles);
    }
  }

  // Update pole status
  updatePoleStatus(poleId: string, status: PoleStatusType): void {
    this.updatePole(poleId, { status, lastHeartbeat: new Date().toISOString() });
  }

  // Update pole battery level
  updatePoleBattery(poleId: string, batteryLevel: number): void {
    this.updatePole(poleId, { batteryLevel });
  }

  // Update pole signal strength
  updatePoleSignal(poleId: string, signalStrength: LoRaSignalStrength): void {
    this.updatePole(poleId, { signalStrength });
  }

  // Delete pole
  deletePole(poleId: string): void {
    const poles = this.getPoles().filter(p => p.poleId !== poleId);
    this.savePoles(poles);
  }

  // Send heartbeat for pole
  sendHeartbeat(poleId: string): void {
    this.updatePole(poleId, { lastHeartbeat: new Date().toISOString() });
  }

  // Gateway operations
  getGateways(): LoRaGateway[] {
    try {
      const data = localStorage.getItem(GATEWAYS_STORAGE_KEY);
      return data ? JSON.parse(data) : [];
    } catch (error) {
      console.error('Error reading gateways:', error);
      return [];
    }
  }

  getGatewayById(gatewayId: string): LoRaGateway | null {
    const gateways = this.getGateways();
    return gateways.find(g => g.gatewayId === gatewayId) || null;
  }

  private saveGateways(gateways: LoRaGateway[]): void {
    try {
      localStorage.setItem(GATEWAYS_STORAGE_KEY, JSON.stringify(gateways));
      this.dispatchGatewayEvent();
    } catch (error) {
      console.error('Error saving gateways:', error);
    }
  }

  createGateway(gatewayData: Omit<LoRaGateway, 'id' | 'lastUpdate'>): LoRaGateway {
    const newGateway: LoRaGateway = {
      ...gatewayData,
      id: `gateway_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      lastUpdate: new Date().toISOString(),
    };

    const gateways = this.getGateways();
    gateways.push(newGateway);
    this.saveGateways(gateways);

    return newGateway;
  }

  updateGateway(gatewayId: string, updates: Partial<LoRaGateway>): void {
    const gateways = this.getGateways();
    const gatewayIndex = gateways.findIndex(g => g.gatewayId === gatewayId);

    if (gatewayIndex !== -1) {
      gateways[gatewayIndex] = { 
        ...gateways[gatewayIndex], 
        ...updates,
        lastUpdate: new Date().toISOString()
      };
      this.saveGateways(gateways);
    }
  }

  // LoRa Message operations
  getLoRaMessages(): LoRaMessage[] {
    try {
      const data = localStorage.getItem(LORA_MESSAGES_KEY);
      return data ? JSON.parse(data) : [];
    } catch (error) {
      console.error('Error reading LoRa messages:', error);
      return [];
    }
  }

  private saveLoRaMessages(messages: LoRaMessage[]): void {
    try {
      // Keep only last 100 messages
      const limitedMessages = messages.slice(-100);
      localStorage.setItem(LORA_MESSAGES_KEY, JSON.stringify(limitedMessages));
      this.dispatchLoRaMessageEvent();
    } catch (error) {
      console.error('Error saving LoRa messages:', error);
    }
  }

  createLoRaMessage(messageData: Omit<LoRaMessage, 'id' | 'timestamp'>): LoRaMessage {
    const newMessage: LoRaMessage = {
      ...messageData,
      id: `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date().toISOString(),
    };

    const messages = this.getLoRaMessages();
    messages.push(newMessage);
    this.saveLoRaMessages(messages);

    return newMessage;
  }

  getMessagesByPole(poleId: string): LoRaMessage[] {
    return this.getLoRaMessages().filter(m => m.poleId === poleId);
  }

  getMessagesByType(messageType: LoRaMessage['messageType']): LoRaMessage[] {
    return this.getLoRaMessages().filter(m => m.messageType === messageType);
  }

  // Simulate LoRa communication
  simulateLoRaMessage(poleId: string, messageType: LoRaMessage['messageType'], payload: string): void {
    const pole = this.getPoleById(poleId);
    const gateway = this.getGateways()[0]; // Use first gateway

    if (pole && gateway) {
      this.createLoRaMessage({
        poleId,
        gatewayId: gateway.gatewayId,
        messageType,
        payload,
        rssi: -50 - Math.random() * 50, // Simulate RSSI between -50 and -100
        snr: 5 + Math.random() * 10, // Simulate SNR between 5 and 15
      });

      // Update pole heartbeat
      this.sendHeartbeat(poleId);
    }
  }

  // Get statistics
  getStatistics() {
    const poles = this.getPoles();
    const gateways = this.getGateways();
    const messages = this.getLoRaMessages();

    return {
      totalPoles: poles.length,
      onlinePoles: poles.filter(p => p.status === 'online').length,
      offlinePoles: poles.filter(p => p.status === 'offline').length,
      maintenancePoles: poles.filter(p => p.status === 'maintenance').length,
      errorPoles: poles.filter(p => p.status === 'error').length,
      totalGateways: gateways.length,
      activeGateways: gateways.filter(g => g.status === 'active').length,
      totalMessages: messages.length,
      emergencyMessages: messages.filter(m => m.messageType === 'emergency').length,
      averageBattery: poles.reduce((sum, p) => sum + p.batteryLevel, 0) / poles.length || 0,
    };
  }

  // Event dispatchers
  private dispatchPoleEvent(): void {
    window.dispatchEvent(new CustomEvent(POLE_UPDATE_EVENT, {
      detail: { poles: this.getPoles() }
    }));
  }

  private dispatchGatewayEvent(): void {
    window.dispatchEvent(new CustomEvent(GATEWAY_UPDATE_EVENT, {
      detail: { gateways: this.getGateways() }
    }));
  }

  private dispatchLoRaMessageEvent(): void {
    window.dispatchEvent(new CustomEvent(LORA_MESSAGE_EVENT, {
      detail: { messages: this.getLoRaMessages() }
    }));
  }

  // Subscriptions
  subscribeToPoles(callback: (poles: Pole[]) => void): () => void {
    const handler = (event: Event) => {
      const customEvent = event as CustomEvent;
      callback(customEvent.detail.poles);
    };

    window.addEventListener(POLE_UPDATE_EVENT, handler);
    return () => window.removeEventListener(POLE_UPDATE_EVENT, handler);
  }

  subscribeToGateways(callback: (gateways: LoRaGateway[]) => void): () => void {
    const handler = (event: Event) => {
      const customEvent = event as CustomEvent;
      callback(customEvent.detail.gateways);
    };

    window.addEventListener(GATEWAY_UPDATE_EVENT, handler);
    return () => window.removeEventListener(GATEWAY_UPDATE_EVENT, handler);
  }

  subscribeToLoRaMessages(callback: (messages: LoRaMessage[]) => void): () => void {
    const handler = (event: Event) => {
      const customEvent = event as CustomEvent;
      callback(customEvent.detail.messages);
    };

    window.addEventListener(LORA_MESSAGE_EVENT, handler);
    return () => window.removeEventListener(LORA_MESSAGE_EVENT, handler);
  }

  // Clear all data
  clearAllData(): void {
    localStorage.removeItem(POLES_STORAGE_KEY);
    localStorage.removeItem(GATEWAYS_STORAGE_KEY);
    localStorage.removeItem(LORA_MESSAGES_KEY);
    this.initializeSampleData();
  }
}

// Export singleton instance
export const poleService = new PoleService();
