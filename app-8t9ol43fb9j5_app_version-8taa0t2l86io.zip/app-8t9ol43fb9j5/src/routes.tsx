import React, { type ReactNode } from 'react';
import UserInterface from './pages/UserInterface';
import AdminDashboard from './pages/AdminDashboard';
import GatewayOperations from './pages/GatewayOperations';

interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
}

const routes: RouteConfig[] = [
  {
    name: 'User Interface',
    path: '/',
    element: <UserInterface />,
    visible: true
  },
  {
    name: 'Admin Dashboard',
    path: '/admin',
    element: <AdminDashboard />,
    visible: true
  },
  {
    name: 'Gateway Operations',
    path: '/gateway',
    element: <GatewayOperations />,
    visible: true
  }
];

export default routes;
