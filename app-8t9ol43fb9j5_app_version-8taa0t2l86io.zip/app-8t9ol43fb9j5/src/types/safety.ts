// Type definitions for Women Safety System

export type AlertPriority = 'high' | 'medium' | 'low';
export type AlertStatus = 'active' | 'resolved' | 'notified';
export type PoleStatusType = 'online' | 'offline' | 'maintenance' | 'error';
export type LoRaSignalStrength = 'excellent' | 'good' | 'fair' | 'poor';

export interface Alert {
  id: string;
  poleId: string;
  location: string;
  timestamp: string;
  priority: AlertPriority;
  status: AlertStatus;
  zone?: string;
  voiceChannelActive?: boolean;
  resolvedAt?: string;
  notifiedAuthorities?: string[];
}

export interface AlertAggregation {
  zone: string;
  count: number;
  alerts: Alert[];
}

export interface PoleStatus {
  poleId: string;
  networkStatus: 'offline' | 'online';
  lastUpdate: string;
}

export interface VoiceChannel {
  active: boolean;
  poleId: string;
  startedAt?: string;
}

// Pole Management Types
export interface Pole {
  id: string;
  poleId: string;
  location: string;
  zone: string;
  latitude?: number;
  longitude?: number;
  status: PoleStatusType;
  loraDeviceId: string;
  loraFrequency: string;
  signalStrength: LoRaSignalStrength;
  batteryLevel: number;
  lastHeartbeat: string;
  installationDate: string;
  maintenanceDate?: string;
  notes?: string;
}

export interface LoRaGateway {
  id: string;
  gatewayId: string;
  name: string;
  location: string;
  status: 'active' | 'inactive';
  connectedPoles: number;
  signalRange: number; // in meters
  lastUpdate: string;
}

export interface LoRaMessage {
  id: string;
  timestamp: string;
  poleId: string;
  gatewayId: string;
  messageType: 'heartbeat' | 'emergency' | 'status' | 'test';
  payload: string;
  rssi: number; // Received Signal Strength Indicator
  snr: number; // Signal-to-Noise Ratio
}
