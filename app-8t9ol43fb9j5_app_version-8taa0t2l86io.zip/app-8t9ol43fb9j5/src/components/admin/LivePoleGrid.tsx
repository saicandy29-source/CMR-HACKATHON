// Live Pole Status Grid Component
import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { MapPin, Battery, Signal, Activity } from 'lucide-react';
import { poleService } from '@/services/poleService';
import type { Pole } from '@/types/safety';

export function LivePoleGrid() {
  const [poles, setPoles] = useState<Pole[]>([]);

  useEffect(() => {
    setPoles(poleService.getPoles());

    const unsubscribe = poleService.subscribeToPoles((updatedPoles) => {
      setPoles(updatedPoles);
    });

    return unsubscribe;
  }, []);

  const getStatusColor = (status: Pole['status']) => {
    switch (status) {
      case 'online': return 'bg-success text-success-foreground';
      case 'offline': return 'bg-muted text-muted-foreground';
      case 'maintenance': return 'bg-warning text-warning-foreground';
      case 'error': return 'bg-emergency text-emergency-foreground';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getSignalIcon = (strength: Pole['signalStrength']) => {
    const colors = {
      excellent: 'text-success',
      good: 'text-info',
      fair: 'text-warning',
      poor: 'text-emergency',
    };
    return <Signal className={`w-4 h-4 ${colors[strength]}`} />;
  };

  const getBatteryColor = (level: number) => {
    if (level > 70) return 'text-success';
    if (level > 30) return 'text-warning';
    return 'text-emergency';
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MapPin className="w-6 h-6" />
          Live Pole Status Grid
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {poles.map((pole) => (
            <Card key={pole.id} className="border-l-4 border-l-primary hover:shadow-md transition-shadow">
              <CardContent className="p-4">
                <div className="space-y-3">
                  {/* Header */}
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-semibold">{pole.poleId}</h3>
                      <p className="text-xs text-muted-foreground">{pole.location}</p>
                    </div>
                    <Badge className={getStatusColor(pole.status)} variant="default">
                      {pole.status}
                    </Badge>
                  </div>

                  {/* Zone */}
                  <div className="flex items-center gap-2 text-sm">
                    <MapPin className="w-4 h-4 text-muted-foreground" />
                    <span>{pole.zone}</span>
                  </div>

                  {/* Metrics */}
                  <div className="grid grid-cols-2 gap-2">
                    <div className="flex items-center gap-2 text-sm">
                      {getSignalIcon(pole.signalStrength)}
                      <span className="capitalize text-xs">{pole.signalStrength}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Battery className={`w-4 h-4 ${getBatteryColor(pole.batteryLevel)}`} />
                      <span className="text-xs">{pole.batteryLevel}%</span>
                    </div>
                  </div>

                  {/* Last Heartbeat */}
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Activity className="w-3 h-3" />
                    <span>
                      Last: {new Date(pole.lastHeartbeat).toLocaleTimeString()}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {poles.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">
            <MapPin className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>No poles registered yet</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
