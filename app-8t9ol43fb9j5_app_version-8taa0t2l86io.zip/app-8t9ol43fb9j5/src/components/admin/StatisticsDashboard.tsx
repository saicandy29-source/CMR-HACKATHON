// Real-time Statistics Dashboard Component
import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Activity, AlertTriangle, Battery, Radio, TrendingUp, MapPin } from 'lucide-react';
import { poleService } from '@/services/poleService';
import { alertService } from '@/services/alertService';

export function StatisticsDashboard() {
  const [stats, setStats] = useState(poleService.getStatistics());
  const [alertCount, setAlertCount] = useState(0);

  useEffect(() => {
    const updateStats = () => {
      setStats(poleService.getStatistics());
      setAlertCount(alertService.getActiveAlerts().length);
    };

    updateStats();

    const unsubPoles = poleService.subscribeToPoles(() => {
      updateStats();
    });

    const unsubAlerts = alertService.subscribeToAlerts(() => {
      updateStats();
    });

    // Update every 5 seconds
    const interval = setInterval(updateStats, 5000);

    return () => {
      unsubPoles();
      unsubAlerts();
      clearInterval(interval);
    };
  }, []);

  const statCards = [
    {
      title: 'Total Poles',
      value: stats.totalPoles,
      icon: MapPin,
      color: 'text-primary',
      bgColor: 'bg-primary/10',
    },
    {
      title: 'Online Poles',
      value: stats.onlinePoles,
      icon: Activity,
      color: 'text-success',
      bgColor: 'bg-success/10',
    },
    {
      title: 'Active Alerts',
      value: alertCount,
      icon: AlertTriangle,
      color: 'text-emergency',
      bgColor: 'bg-emergency/10',
    },
    {
      title: 'Offline Poles',
      value: stats.offlinePoles,
      icon: Radio,
      color: 'text-muted-foreground',
      bgColor: 'bg-muted',
    },
    {
      title: 'Avg Battery',
      value: `${stats.averageBattery.toFixed(0)}%`,
      icon: Battery,
      color: stats.averageBattery > 70 ? 'text-success' : stats.averageBattery > 30 ? 'text-warning' : 'text-emergency',
      bgColor: stats.averageBattery > 70 ? 'bg-success/10' : stats.averageBattery > 30 ? 'bg-warning/10' : 'bg-emergency/10',
    },
    {
      title: 'LoRa Messages',
      value: stats.totalMessages,
      icon: TrendingUp,
      color: 'text-info',
      bgColor: 'bg-info/10',
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
      {statCards.map((stat, index) => {
        const Icon = stat.icon;
        return (
          <Card key={index}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">{stat.title}</p>
                  <p className="text-2xl font-bold">{stat.value}</p>
                </div>
                <div className={`p-3 rounded-full ${stat.bgColor}`}>
                  <Icon className={`w-6 h-6 ${stat.color}`} />
                </div>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
