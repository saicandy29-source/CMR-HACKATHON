// Alert History Component
import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Clock, MapPin, CheckCircle } from 'lucide-react';
import type { Alert } from '@/types/safety';
import { alertService } from '@/services/alertService';

export function AlertHistory() {
  const [alerts, setAlerts] = useState<Alert[]>([]);

  useEffect(() => {
    // Load initial alerts
    setAlerts(alertService.getAlerts());

    // Subscribe to real-time updates
    const unsubscribe = alertService.subscribeToAlerts(() => {
      setAlerts(alertService.getAlerts());
    });

    return unsubscribe;
  }, []);

  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const getStatusColor = (status: Alert['status']) => {
    switch (status) {
      case 'active':
        return 'bg-emergency text-emergency-foreground';
      case 'notified':
        return 'bg-warning text-warning-foreground';
      case 'resolved':
        return 'bg-success text-success-foreground';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Clock className="w-6 h-6" />
          Alert History Logs
          <Badge variant="secondary" className="ml-auto">
            {alerts.length} Total
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {alerts.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <Clock className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>No alerts recorded yet</p>
          </div>
        ) : (
          <ScrollArea className="h-[400px] pr-4">
            <div className="space-y-3">
              {alerts.map((alert) => (
                <Card key={alert.id} className="border-l-4 border-l-border">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 space-y-2">
                        {/* Status and Priority */}
                        <div className="flex items-center gap-2 flex-wrap">
                          <Badge className={getStatusColor(alert.status)}>
                            {alert.status}
                          </Badge>
                          <Badge variant="outline">
                            {alert.priority} priority
                          </Badge>
                        </div>

                        {/* Alert Info */}
                        <div className="space-y-1 text-sm">
                          <div className="flex items-center gap-2">
                            <MapPin className="w-4 h-4 text-muted-foreground" />
                            <span className="font-mono font-semibold">{alert.poleId}</span>
                            <span className="text-muted-foreground">•</span>
                            <span>{alert.location}</span>
                            {alert.zone && (
                              <>
                                <span className="text-muted-foreground">•</span>
                                <span>{alert.zone}</span>
                              </>
                            )}
                          </div>

                          <div className="flex items-center gap-2 text-muted-foreground">
                            <Clock className="w-4 h-4" />
                            <span>{formatTimestamp(alert.timestamp)}</span>
                          </div>

                          {alert.resolvedAt && (
                            <div className="flex items-center gap-2 text-success">
                              <CheckCircle className="w-4 h-4" />
                              <span className="text-sm">
                                Resolved at {formatTimestamp(alert.resolvedAt)}
                              </span>
                            </div>
                          )}

                          {alert.notifiedAuthorities && alert.notifiedAuthorities.length > 0 && (
                            <div className="flex items-center gap-2">
                              <span className="text-xs font-semibold">Notified:</span>
                              <div className="flex gap-1">
                                {alert.notifiedAuthorities.map((auth) => (
                                  <Badge key={auth} variant="secondary" className="text-xs">
                                    {auth}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </ScrollArea>
        )}
      </CardContent>
    </Card>
  );
}
