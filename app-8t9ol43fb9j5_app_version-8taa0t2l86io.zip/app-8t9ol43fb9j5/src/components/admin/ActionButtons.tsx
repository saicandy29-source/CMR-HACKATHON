// Action Buttons Component for Admin Dashboard
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Shield, Phone, CheckCircle } from 'lucide-react';
import { alertService } from '@/services/alertService';
import { useToast } from '@/hooks/use-toast';

interface ActionButtonsProps {
  selectedAlertId: string | null;
}

export function ActionButtons({ selectedAlertId }: ActionButtonsProps) {
  const { toast } = useToast();

  const handleNotifyPolice = () => {
    if (!selectedAlertId) {
      toast({
        title: 'No Alert Selected',
        description: 'Please select an alert from the panel above.',
        variant: 'destructive',
      });
      return;
    }

    alertService.notifyAuthority(selectedAlertId, 'Police');
    toast({
      title: 'Police Notified',
      description: 'Emergency services have been alerted.',
    });
  };

  const handleNotifySecurity = () => {
    if (!selectedAlertId) {
      toast({
        title: 'No Alert Selected',
        description: 'Please select an alert from the panel above.',
        variant: 'destructive',
      });
      return;
    }

    alertService.notifyAuthority(selectedAlertId, 'Campus Security');
    toast({
      title: 'Campus Security Notified',
      description: 'Security team has been dispatched.',
    });
  };

  const handleMarkResolved = () => {
    if (!selectedAlertId) {
      toast({
        title: 'No Alert Selected',
        description: 'Please select an alert from the panel above.',
        variant: 'destructive',
      });
      return;
    }

    alertService.updateAlertStatus(selectedAlertId, 'resolved');
    toast({
      title: 'Alert Resolved',
      description: 'The alert has been marked as resolved.',
      variant: 'default',
    });
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Response Actions</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Button
            onClick={handleNotifyPolice}
            className="h-24 flex flex-col items-center justify-center gap-2 bg-emergency hover:bg-emergency/90 text-emergency-foreground"
            disabled={!selectedAlertId}
          >
            <Phone className="w-8 h-8" />
            <span className="font-semibold">Notify Police</span>
          </Button>

          <Button
            onClick={handleNotifySecurity}
            className="h-24 flex flex-col items-center justify-center gap-2 bg-warning hover:bg-warning/90 text-warning-foreground"
            disabled={!selectedAlertId}
          >
            <Shield className="w-8 h-8" />
            <span className="font-semibold">Notify Campus Security</span>
          </Button>

          <Button
            onClick={handleMarkResolved}
            className="h-24 flex flex-col items-center justify-center gap-2 bg-success hover:bg-success/90 text-success-foreground"
            disabled={!selectedAlertId}
          >
            <CheckCircle className="w-8 h-8" />
            <span className="font-semibold">Mark as Resolved</span>
          </Button>
        </div>

        {!selectedAlertId && (
          <p className="text-sm text-muted-foreground text-center mt-4">
            Click on an alert above to enable response actions
          </p>
        )}
      </CardContent>
    </Card>
  );
}
