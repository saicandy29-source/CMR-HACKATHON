// Alert Panel Component for Admin Dashboard
import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { AlertCircle, MapPin, Clock, Mic } from 'lucide-react';
import type { Alert } from '@/types/safety';
import { alertService } from '@/services/alertService';

interface AlertPanelProps {
  onVoiceChannelToggle: (alertId: string, active: boolean) => void;
}

export function AlertPanel({ onVoiceChannelToggle }: AlertPanelProps) {
  const [activeAlerts, setActiveAlerts] = useState<Alert[]>([]);

  useEffect(() => {
    // Load initial alerts
    setActiveAlerts(alertService.getActiveAlerts());

    // Subscribe to real-time updates
    const unsubscribe = alertService.subscribeToAlerts(() => {
      setActiveAlerts(alertService.getActiveAlerts());
    });

    return unsubscribe;
  }, []);

  const getPriorityColor = (priority: Alert['priority']) => {
    switch (priority) {
      case 'high':
        return 'bg-emergency text-emergency-foreground';
      case 'medium':
        return 'bg-warning text-warning-foreground';
      case 'low':
        return 'bg-muted text-muted-foreground';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  const getPriorityBorder = (priority: Alert['priority']) => {
    switch (priority) {
      case 'high':
        return 'border-l-4 border-l-emergency';
      case 'medium':
        return 'border-l-4 border-l-warning';
      case 'low':
        return 'border-l-4 border-l-muted';
      default:
        return '';
    }
  };

  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
  };

  const getTimeAgo = (timestamp: string) => {
    const now = Date.now();
    const alertTime = new Date(timestamp).getTime();
    const diffSeconds = Math.floor((now - alertTime) / 1000);

    if (diffSeconds < 60) return `${diffSeconds}s ago`;
    if (diffSeconds < 3600) return `${Math.floor(diffSeconds / 60)}m ago`;
    return `${Math.floor(diffSeconds / 3600)}h ago`;
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <AlertCircle className="w-6 h-6 text-emergency" />
          Real-Time Alert Panel
          {activeAlerts.length > 0 && (
            <Badge variant="destructive" className="ml-auto">
              {activeAlerts.length} Active
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent>
        {activeAlerts.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <AlertCircle className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p className="text-lg font-medium">No Active Alerts</p>
            <p className="text-sm">All systems operational</p>
          </div>
        ) : (
          <div className="space-y-4">
            {activeAlerts.map((alert) => (
              <Card
                key={alert.id}
                className={`${getPriorityBorder(alert.priority)} transition-all duration-200 hover:shadow-md`}
              >
                <CardContent className="p-4">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 space-y-2">
                      {/* Header */}
                      <div className="flex items-center gap-2 flex-wrap">
                        <Badge className={getPriorityColor(alert.priority)}>
                          {alert.priority.toUpperCase()} PRIORITY
                        </Badge>
                        <Badge variant="outline">{alert.status}</Badge>
                        {alert.voiceChannelActive && (
                          <Badge variant="default" className="bg-success">
                            <Mic className="w-3 h-3 mr-1" />
                            Voice Active
                          </Badge>
                        )}
                      </div>

                      {/* Alert Details */}
                      <div className="space-y-1">
                        <div className="flex items-center gap-2 text-sm">
                          <MapPin className="w-4 h-4 text-muted-foreground" />
                          <span className="font-semibold">Pole ID:</span>
                          <span className="font-mono">{alert.poleId}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm">
                          <MapPin className="w-4 h-4 text-muted-foreground" />
                          <span className="font-semibold">Location:</span>
                          <span>{alert.location}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm">
                          <Clock className="w-4 h-4 text-muted-foreground" />
                          <span className="font-semibold">Time:</span>
                          <span>{formatTimestamp(alert.timestamp)}</span>
                          <span className="text-muted-foreground">({getTimeAgo(alert.timestamp)})</span>
                        </div>
                        {alert.zone && (
                          <div className="flex items-center gap-2 text-sm">
                            <span className="font-semibold">Zone:</span>
                            <span>{alert.zone}</span>
                          </div>
                        )}
                      </div>

                      {/* Notified Authorities */}
                      {alert.notifiedAuthorities && alert.notifiedAuthorities.length > 0 && (
                        <div className="flex items-center gap-2 text-sm">
                          <span className="font-semibold">Notified:</span>
                          <div className="flex gap-1">
                            {alert.notifiedAuthorities.map((auth) => (
                              <Badge key={auth} variant="secondary" className="text-xs">
                                {auth}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Voice Channel Toggle */}
                    <Button
                      size="sm"
                      variant={alert.voiceChannelActive ? 'default' : 'outline'}
                      onClick={() => onVoiceChannelToggle(alert.id, !alert.voiceChannelActive)}
                      className="shrink-0"
                    >
                      <Mic className="w-4 h-4 mr-2" />
                      {alert.voiceChannelActive ? 'Disconnect' : 'Connect'}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
