// Alert Aggregation Component
import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { MapPin, AlertTriangle } from 'lucide-react';
import { alertService } from '@/services/alertService';

export function AlertAggregation() {
  const [aggregation, setAggregation] = useState<Array<{ zone: string; count: number }>>([]);

  useEffect(() => {
    const updateAggregation = () => {
      const agg = alertService.getAlertAggregation();
      setAggregation(agg.map(a => ({ zone: a.zone, count: a.count })));
    };

    updateAggregation();

    const unsubscribe = alertService.subscribeToAlerts(() => {
      updateAggregation();
    });

    return unsubscribe;
  }, []);

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MapPin className="w-6 h-6" />
          Alert Aggregation by Zone
        </CardTitle>
      </CardHeader>
      <CardContent>
        {aggregation.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <MapPin className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>No active alerts in any zone</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {aggregation.map((item) => (
              <Card key={item.zone} className="border-l-4 border-l-warning">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <AlertTriangle className="w-5 h-5 text-warning" />
                      <span className="font-semibold">{item.zone}</span>
                    </div>
                    <Badge variant="destructive" className="text-lg font-bold">
                      {item.count}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mt-2">
                    {item.count === 1 ? '1 Alert' : `${item.count} Alerts`} in this zone
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
