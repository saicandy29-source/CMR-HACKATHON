// Emergency Button Component with long-press functionality
import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { AlertCircle } from 'lucide-react';

interface EmergencyButtonProps {
  onEmergencyTriggered: () => void;
  disabled?: boolean;
}

const LONG_PRESS_DURATION = 3000; // 3 seconds

export function EmergencyButton({ onEmergencyTriggered, disabled }: EmergencyButtonProps) {
  const [isPressed, setIsPressed] = useState(false);
  const [progress, setProgress] = useState(0);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const progressIntervalRef = useRef<NodeJS.Timeout | null>(null);

  const startPress = () => {
    if (disabled) return;
    
    setIsPressed(true);
    setProgress(0);

    // Progress animation
    const startTime = Date.now();
    progressIntervalRef.current = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const newProgress = Math.min((elapsed / LONG_PRESS_DURATION) * 100, 100);
      setProgress(newProgress);
    }, 50);

    // Trigger emergency after long press duration
    timerRef.current = setTimeout(() => {
      onEmergencyTriggered();
      setIsPressed(false);
      setProgress(0);
      clearInterval(progressIntervalRef.current!);
    }, LONG_PRESS_DURATION);
  };

  const cancelPress = () => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
      timerRef.current = null;
    }
    if (progressIntervalRef.current) {
      clearInterval(progressIntervalRef.current);
      progressIntervalRef.current = null;
    }
    setIsPressed(false);
    setProgress(0);
  };

  useEffect(() => {
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
      if (progressIntervalRef.current) clearInterval(progressIntervalRef.current);
    };
  }, []);

  return (
    <div className="relative w-full max-w-md mx-auto">
      <Button
        className="w-full h-48 text-3xl font-bold bg-emergency hover:bg-emergency/90 text-emergency-foreground rounded-2xl shadow-2xl transition-all duration-200 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed relative overflow-hidden"
        onMouseDown={startPress}
        onMouseUp={cancelPress}
        onMouseLeave={cancelPress}
        onTouchStart={startPress}
        onTouchEnd={cancelPress}
        disabled={disabled}
      >
        {/* Progress indicator */}
        {isPressed && (
          <div 
            className="absolute bottom-0 left-0 h-2 bg-emergency-foreground/50 transition-all duration-50"
            style={{ width: `${progress}%` }}
          />
        )}
        
        <div className="flex flex-col items-center gap-4">
          <AlertCircle className="w-16 h-16" />
          <span>
            {isPressed ? 'HOLD...' : 'EMERGENCY SOS'}
          </span>
          {!isPressed && (
            <span className="text-sm font-normal">Hold for 3 seconds</span>
          )}
        </div>
      </Button>

      {isPressed && (
        <div className="mt-4 text-center text-muted-foreground animate-pulse">
          Keep holding to trigger emergency alert...
        </div>
      )}
    </div>
  );
}
