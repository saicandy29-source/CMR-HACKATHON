// Push-to-Talk Button Component
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Mic, MicOff } from 'lucide-react';

interface PTTButtonProps {
  enabled: boolean;
  onToggle: (active: boolean) => void;
}

export function PTTButton({ enabled, onToggle }: PTTButtonProps) {
  const [isActive, setIsActive] = useState(false);

  const handleToggle = () => {
    const newState = !isActive;
    setIsActive(newState);
    onToggle(newState);
  };

  return (
    <div className="w-full max-w-md mx-auto">
      <Button
        className="w-full h-24 text-xl font-semibold rounded-xl shadow-lg transition-all duration-200 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
        variant={isActive ? 'default' : 'outline'}
        onClick={handleToggle}
        disabled={!enabled}
      >
        <div className="flex items-center gap-3">
          {isActive ? (
            <>
              <Mic className="w-8 h-8" />
              <div className="flex flex-col items-start">
                <span>Voice Channel Active</span>
                <span className="text-sm font-normal opacity-80">Tap to disconnect</span>
              </div>
            </>
          ) : (
            <>
              <MicOff className="w-8 h-8" />
              <div className="flex flex-col items-start">
                <span>Push to Talk</span>
                <span className="text-sm font-normal opacity-80">
                  {enabled ? 'Tap to connect' : 'Trigger emergency first'}
                </span>
              </div>
            </>
          )}
        </div>
      </Button>

      {isActive && (
        <div className="mt-4 p-4 bg-success/10 border border-success rounded-lg">
          <div className="flex items-center gap-2 text-success">
            <div className="w-3 h-3 bg-success rounded-full animate-pulse" />
            <span className="font-medium">Connected to Control Center</span>
          </div>
          <p className="text-sm text-muted-foreground mt-2">
            Your voice is being transmitted to the emergency response team.
          </p>
        </div>
      )}
    </div>
  );
}
