// Status Indicators Component
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { WifiOff, MapPin, Clock } from 'lucide-react';
import { useEffect, useState } from 'react';

interface StatusIndicatorsProps {
  poleId: string;
  location: string;
}

export function StatusIndicators({ poleId, location }: StatusIndicatorsProps) {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true,
    });
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  return (
    <Card className="p-6 bg-card">
      <div className="space-y-4">
        {/* Network Status */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <WifiOff className="w-5 h-5 text-muted-foreground" />
            <span className="text-sm font-medium">Network Status</span>
          </div>
          <Badge variant="outline" className="bg-warning/10 text-warning border-warning">
            Offline Mode (LoRa)
          </Badge>
        </div>

        {/* Pole ID */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <MapPin className="w-5 h-5 text-muted-foreground" />
            <span className="text-sm font-medium">Pole ID</span>
          </div>
          <span className="text-sm font-mono font-semibold">{poleId}</span>
        </div>

        {/* Location */}
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium">Location</span>
          <span className="text-sm text-muted-foreground">{location}</span>
        </div>

        {/* Current Time */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-muted-foreground" />
            <span className="text-sm font-medium">Current Time</span>
          </div>
          <div className="text-right">
            <div className="text-sm font-semibold">{formatTime(currentTime)}</div>
            <div className="text-xs text-muted-foreground">{formatDate(currentTime)}</div>
          </div>
        </div>
      </div>
    </Card>
  );
}
