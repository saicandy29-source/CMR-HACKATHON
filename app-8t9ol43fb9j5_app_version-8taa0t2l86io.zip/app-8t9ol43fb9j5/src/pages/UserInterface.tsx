// User Interface Page - Smart Safety Pole Simulation
import { useState, useEffect } from 'react';
import { EmergencyButton } from '@/components/emergency/EmergencyButton';
import { PTTButton } from '@/components/emergency/PTTButton';
import { StatusIndicators } from '@/components/emergency/StatusIndicators';
import { alertService } from '@/services/alertService';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertCircle } from 'lucide-react';

const POLE_ID = 'POLE-001';
const LOCATION = 'Campus North Gate, Building A';
const ZONE = 'Zone A';

export default function UserInterface() {
  const [emergencyTriggered, setEmergencyTriggered] = useState(false);
  const [pttEnabled, setPttEnabled] = useState(false);
  const [showAlert, setShowAlert] = useState(false);
  const [currentAlertId, setCurrentAlertId] = useState<string | null>(null);

  useEffect(() => {
    // Subscribe to PTT updates from admin
    const unsubscribe = alertService.subscribeToPTT((poleId, active) => {
      if (poleId === POLE_ID) {
        setPttEnabled(active);
      }
    });

    return unsubscribe;
  }, []);

  const handleEmergencyTriggered = () => {
    // Create emergency alert
    const alert = alertService.createAlert(POLE_ID, LOCATION, ZONE);
    setCurrentAlertId(alert.id);
    setEmergencyTriggered(true);
    setShowAlert(true);

    // Optional: Play alert sound (commented out for demo)
    // const audio = new Audio('/alert-sound.mp3');
    // audio.play();

    // Hide alert message after 5 seconds
    setTimeout(() => {
      setShowAlert(false);
    }, 5000);
  };

  const handlePTTToggle = (active: boolean) => {
    if (currentAlertId) {
      alertService.toggleVoiceChannel(currentAlertId, active);
    }
  };

  return (
    <div
      className={`min-h-screen transition-colors duration-500 ${
        emergencyTriggered && showAlert ? 'bg-emergency' : 'bg-background'
      }`}
    >
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-6">
          <h1 className="text-2xl xl:text-3xl font-bold text-center">
            Smart Safety Pole – Emergency Interface
          </h1>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8 xl:py-12">
        <div className="max-w-4xl mx-auto space-y-8">
          {/* Emergency Alert Message */}
          {emergencyTriggered && showAlert && (
            <Alert className="bg-emergency-foreground border-emergency animate-pulse">
              <AlertCircle className="h-6 w-6 text-emergency" />
              <AlertDescription className="text-lg font-bold text-emergency">
                ⚠️ EMERGENCY ALERT TRIGGERED ⚠️
                <br />
                <span className="text-base font-normal">
                  Your alert has been sent to the Control Center. Help is on the way.
                </span>
              </AlertDescription>
            </Alert>
          )}

          {/* Status Indicators */}
          <StatusIndicators poleId={POLE_ID} location={LOCATION} />

          {/* Emergency Button */}
          <div className="py-8">
            <EmergencyButton
              onEmergencyTriggered={handleEmergencyTriggered}
              disabled={emergencyTriggered}
            />
            {emergencyTriggered && (
              <p className="text-center mt-4 text-success font-semibold">
                ✓ Emergency alert sent successfully
              </p>
            )}
          </div>

          {/* Push-to-Talk Button */}
          <PTTButton enabled={emergencyTriggered} onToggle={handlePTTToggle} />
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-border bg-card/50 backdrop-blur-sm mt-12">
        <div className="container mx-auto px-4 py-6">
          <p className="text-center text-sm text-muted-foreground">
            ℹ️ Works without internet in real deployment (LoRa Technology)
          </p>
          <p className="text-center text-xs text-muted-foreground mt-2">
            © 2026 Women Safety System
          </p>
        </div>
      </footer>
    </div>
  );
}
