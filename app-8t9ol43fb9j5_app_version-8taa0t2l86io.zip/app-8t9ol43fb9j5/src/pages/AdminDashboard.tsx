// Admin Dashboard Page - Control Center
import { useState, useEffect } from 'react';
import { AlertPanel } from '@/components/admin/AlertPanel';
import { AlertAggregation } from '@/components/admin/AlertAggregation';
import { AlertHistory } from '@/components/admin/AlertHistory';
import { ActionButtons } from '@/components/admin/ActionButtons';
import { LivePoleGrid } from '@/components/admin/LivePoleGrid';
import { StatisticsDashboard } from '@/components/admin/StatisticsDashboard';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Shield, Trash2, Radio, BarChart3 } from 'lucide-react';
import { alertService } from '@/services/alertService';
import { useToast } from '@/hooks/use-toast';
import { Link } from 'react-router-dom';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

export default function AdminDashboard() {
  const [selectedAlertId, setSelectedAlertId] = useState<string | null>(null);
  const [activeAlertsCount, setActiveAlertsCount] = useState(0);
  const { toast } = useToast();

  useEffect(() => {
    const updateCount = () => {
      setActiveAlertsCount(alertService.getActiveAlerts().length);
    };

    updateCount();

    const unsubscribe = alertService.subscribeToAlerts(() => {
      updateCount();
    });

    return unsubscribe;
  }, []);

  const handleVoiceChannelToggle = (alertId: string, active: boolean) => {
    alertService.toggleVoiceChannel(alertId, active);
    setSelectedAlertId(alertId);
    
    toast({
      title: active ? 'Voice Channel Connected' : 'Voice Channel Disconnected',
      description: active
        ? 'You are now connected to the emergency pole.'
        : 'Voice communication has been ended.',
    });
  };

  const handleClearAllAlerts = () => {
    alertService.clearAllAlerts();
    setSelectedAlertId(null);
    toast({
      title: 'All Alerts Cleared',
      description: 'Alert history has been reset.',
    });
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card shadow-sm sticky top-0 z-10 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4 xl:py-6">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-3">
              <Shield className="w-8 h-8 text-primary" />
              <div>
                <h1 className="text-xl xl:text-3xl font-bold">
                  Women Safety Control Center Dashboard
                </h1>
                <p className="text-sm text-muted-foreground">
                  Real-time emergency monitoring and response system
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              {activeAlertsCount > 0 && (
                <Badge variant="destructive" className="text-lg px-4 py-2">
                  {activeAlertsCount} Active Alert{activeAlertsCount !== 1 ? 's' : ''}
                </Badge>
              )}
              <Link to="/gateway">
                <Button variant="outline" size="sm">
                  <Radio className="w-4 h-4 mr-2" />
                  Gateway Ops
                </Button>
              </Link>
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="outline" size="sm">
                    <Trash2 className="w-4 h-4 mr-2" />
                    Clear All
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Clear All Alerts?</AlertDialogTitle>
                    <AlertDialogDescription>
                      This will permanently delete all alert records from the system. This action cannot be undone.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={handleClearAllAlerts}>
                      Clear All
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-6 xl:py-8">
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="overview">
              <BarChart3 className="w-4 h-4 mr-2" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="alerts">
              <Shield className="w-4 h-4 mr-2" />
              Alerts & Response
            </TabsTrigger>
            <TabsTrigger value="poles">
              <Radio className="w-4 h-4 mr-2" />
              Pole Status
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            {/* Statistics Dashboard */}
            <section>
              <StatisticsDashboard />
            </section>

            {/* Alert Aggregation */}
            <section>
              <AlertAggregation />
            </section>

            {/* Live Pole Grid */}
            <section>
              <LivePoleGrid />
            </section>
          </TabsContent>

          {/* Alerts & Response Tab */}
          <TabsContent value="alerts" className="space-y-6">
            {/* Alert Panel */}
            <section>
              <AlertPanel onVoiceChannelToggle={handleVoiceChannelToggle} />
            </section>

            {/* Action Buttons */}
            <section>
              <ActionButtons selectedAlertId={selectedAlertId} />
            </section>

            {/* Alert History */}
            <section>
              <AlertHistory />
            </section>
          </TabsContent>

          {/* Pole Status Tab */}
          <TabsContent value="poles" className="space-y-6">
            {/* Statistics */}
            <section>
              <StatisticsDashboard />
            </section>

            {/* Live Pole Grid */}
            <section>
              <LivePoleGrid />
            </section>
          </TabsContent>
        </Tabs>
      </main>

      {/* Footer */}
      <footer className="border-t border-border bg-card mt-12">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col xl:flex-row items-center justify-between gap-4">
            <p className="text-sm text-muted-foreground">
              © 2026 Women Safety System - Control Center
            </p>
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <span>System Status: <Badge variant="outline" className="bg-success/10 text-success border-success">Operational</Badge></span>
              <span>LoRa Network: <Badge variant="outline" className="bg-success/10 text-success border-success">Active</Badge></span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
