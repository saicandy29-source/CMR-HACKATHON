// Gateway Operations Page - LoRa ESP32 Simulation and Pole Management
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Radio, 
  MapPin, 
  Activity, 
  Battery, 
  Signal, 
  Plus,
  Trash2,
  RefreshCw,
  Send,
  Database
} from 'lucide-react';
import { poleService } from '@/services/poleService';
import type { Pole, LoRaMessage, LoRaGateway } from '@/types/safety';
import { useToast } from '@/hooks/use-toast';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';

export default function GatewayOperations() {
  const [poles, setPoles] = useState<Pole[]>([]);
  const [gateways, setGateways] = useState<LoRaGateway[]>([]);
  const [messages, setMessages] = useState<LoRaMessage[]>([]);
  const [selectedPole, setSelectedPole] = useState<string>('');
  const [statistics, setStatistics] = useState(poleService.getStatistics());
  const { toast } = useToast();

  // Form state for new pole
  const [newPole, setNewPole] = useState({
    poleId: '',
    location: '',
    zone: 'Zone A',
    loraDeviceId: '',
    loraFrequency: '868.1 MHz',
  });

  useEffect(() => {
    // Load initial data
    setPoles(poleService.getPoles());
    setGateways(poleService.getGateways());
    setMessages(poleService.getLoRaMessages());
    setStatistics(poleService.getStatistics());

    // Subscribe to updates
    const unsubPoles = poleService.subscribeToPoles((updatedPoles) => {
      setPoles(updatedPoles);
      setStatistics(poleService.getStatistics());
    });

    const unsubGateways = poleService.subscribeToGateways((updatedGateways) => {
      setGateways(updatedGateways);
    });

    const unsubMessages = poleService.subscribeToLoRaMessages((updatedMessages) => {
      setMessages(updatedMessages);
    });

    return () => {
      unsubPoles();
      unsubGateways();
      unsubMessages();
    };
  }, []);

  const handleCreatePole = () => {
    if (!newPole.poleId || !newPole.location || !newPole.loraDeviceId) {
      toast({
        title: 'Validation Error',
        description: 'Please fill in all required fields',
        variant: 'destructive',
      });
      return;
    }

    poleService.createPole({
      poleId: newPole.poleId,
      location: newPole.location,
      zone: newPole.zone,
      loraDeviceId: newPole.loraDeviceId,
      loraFrequency: newPole.loraFrequency,
      status: 'online',
      signalStrength: 'good',
      batteryLevel: 100,
      installationDate: new Date().toISOString().split('T')[0],
    });

    toast({
      title: 'Pole Created',
      description: `${newPole.poleId} has been registered successfully`,
    });

    // Reset form
    setNewPole({
      poleId: '',
      location: '',
      zone: 'Zone A',
      loraDeviceId: '',
      loraFrequency: '868.1 MHz',
    });
  };

  const handleDeletePole = (poleId: string) => {
    poleService.deletePole(poleId);
    toast({
      title: 'Pole Deleted',
      description: `${poleId} has been removed from the system`,
    });
  };

  const handleSimulateMessage = (messageType: LoRaMessage['messageType']) => {
    if (!selectedPole) {
      toast({
        title: 'No Pole Selected',
        description: 'Please select a pole to simulate message',
        variant: 'destructive',
      });
      return;
    }

    const payloads = {
      heartbeat: 'STATUS_OK',
      emergency: 'EMERGENCY_ALERT',
      status: 'BATTERY_LOW',
      test: 'TEST_MESSAGE',
    };

    poleService.simulateLoRaMessage(selectedPole, messageType, payloads[messageType]);

    toast({
      title: 'Message Sent',
      description: `${messageType.toUpperCase()} message sent from ${selectedPole}`,
    });
  };

  const getStatusColor = (status: Pole['status']) => {
    switch (status) {
      case 'online': return 'bg-success text-success-foreground';
      case 'offline': return 'bg-muted text-muted-foreground';
      case 'maintenance': return 'bg-warning text-warning-foreground';
      case 'error': return 'bg-emergency text-emergency-foreground';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getSignalColor = (strength: Pole['signalStrength']) => {
    switch (strength) {
      case 'excellent': return 'text-success';
      case 'good': return 'text-info';
      case 'fair': return 'text-warning';
      case 'poor': return 'text-emergency';
      default: return 'text-muted-foreground';
    }
  };

  const getBatteryColor = (level: number) => {
    if (level > 70) return 'text-success';
    if (level > 30) return 'text-warning';
    return 'text-emergency';
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card shadow-sm">
        <div className="container mx-auto px-4 py-4 xl:py-6">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-3">
              <Radio className="w-8 h-8 text-primary" />
              <div>
                <h1 className="text-xl xl:text-3xl font-bold">
                  Gateway Operations - LoRa ESP32 Management
                </h1>
                <p className="text-sm text-muted-foreground">
                  Manage safety poles, monitor LoRa network, and simulate ESP32 communications
                </p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-6 xl:py-8">
        <div className="space-y-6">
          {/* Statistics Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Total Poles</p>
                    <p className="text-3xl font-bold">{statistics.totalPoles}</p>
                  </div>
                  <Database className="w-8 h-8 text-primary" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Online Poles</p>
                    <p className="text-3xl font-bold text-success">{statistics.onlinePoles}</p>
                  </div>
                  <Activity className="w-8 h-8 text-success" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Avg Battery</p>
                    <p className="text-3xl font-bold">{statistics.averageBattery.toFixed(0)}%</p>
                  </div>
                  <Battery className="w-8 h-8 text-info" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">LoRa Messages</p>
                    <p className="text-3xl font-bold">{statistics.totalMessages}</p>
                  </div>
                  <Radio className="w-8 h-8 text-warning" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Tabs */}
          <Tabs defaultValue="poles" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="poles">Pole Management</TabsTrigger>
              <TabsTrigger value="simulation">LoRa Simulation</TabsTrigger>
              <TabsTrigger value="messages">Message Logs</TabsTrigger>
            </TabsList>

            {/* Pole Management Tab */}
            <TabsContent value="poles" className="space-y-4">
              <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
                {/* Register New Pole */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Plus className="w-5 h-5" />
                      Register New Pole
                    </CardTitle>
                    <CardDescription>Add a new safety pole to the system</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="poleId">Pole ID *</Label>
                      <Input
                        id="poleId"
                        placeholder="POLE-004"
                        value={newPole.poleId}
                        onChange={(e) => setNewPole({ ...newPole, poleId: e.target.value })}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="location">Location *</Label>
                      <Input
                        id="location"
                        placeholder="Campus Sports Complex"
                        value={newPole.location}
                        onChange={(e) => setNewPole({ ...newPole, location: e.target.value })}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="zone">Zone</Label>
                      <Select value={newPole.zone} onValueChange={(value) => setNewPole({ ...newPole, zone: value })}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Zone A">Zone A</SelectItem>
                          <SelectItem value="Zone B">Zone B</SelectItem>
                          <SelectItem value="Zone C">Zone C</SelectItem>
                          <SelectItem value="Zone D">Zone D</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="loraDeviceId">LoRa Device ID *</Label>
                      <Input
                        id="loraDeviceId"
                        placeholder="LORA-DEV-004"
                        value={newPole.loraDeviceId}
                        onChange={(e) => setNewPole({ ...newPole, loraDeviceId: e.target.value })}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="loraFrequency">LoRa Frequency</Label>
                      <Select value={newPole.loraFrequency} onValueChange={(value) => setNewPole({ ...newPole, loraFrequency: value })}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="868.1 MHz">868.1 MHz</SelectItem>
                          <SelectItem value="868.3 MHz">868.3 MHz</SelectItem>
                          <SelectItem value="868.5 MHz">868.5 MHz</SelectItem>
                          <SelectItem value="915.0 MHz">915.0 MHz</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <Button onClick={handleCreatePole} className="w-full">
                      <Plus className="w-4 h-4 mr-2" />
                      Register Pole
                    </Button>
                  </CardContent>
                </Card>

                {/* Pole List */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <MapPin className="w-5 h-5" />
                      Registered Poles
                    </CardTitle>
                    <CardDescription>View and manage all safety poles</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ScrollArea className="h-[500px] pr-4">
                      <div className="space-y-3">
                        {poles.map((pole) => (
                          <Card key={pole.id} className="border-l-4 border-l-primary">
                            <CardContent className="p-4">
                              <div className="space-y-3">
                                {/* Header */}
                                <div className="flex items-start justify-between">
                                  <div>
                                    <h3 className="font-semibold text-lg">{pole.poleId}</h3>
                                    <p className="text-sm text-muted-foreground">{pole.location}</p>
                                  </div>
                                  <Badge className={getStatusColor(pole.status)}>
                                    {pole.status}
                                  </Badge>
                                </div>

                                {/* Details */}
                                <div className="grid grid-cols-2 gap-2 text-sm">
                                  <div className="flex items-center gap-2">
                                    <MapPin className="w-4 h-4 text-muted-foreground" />
                                    <span>{pole.zone}</span>
                                  </div>
                                  <div className="flex items-center gap-2">
                                    <Radio className="w-4 h-4 text-muted-foreground" />
                                    <span>{pole.loraDeviceId}</span>
                                  </div>
                                  <div className="flex items-center gap-2">
                                    <Signal className={`w-4 h-4 ${getSignalColor(pole.signalStrength)}`} />
                                    <span className="capitalize">{pole.signalStrength}</span>
                                  </div>
                                  <div className="flex items-center gap-2">
                                    <Battery className={`w-4 h-4 ${getBatteryColor(pole.batteryLevel)}`} />
                                    <span>{pole.batteryLevel}%</span>
                                  </div>
                                </div>

                                {/* Actions */}
                                <div className="flex gap-2">
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => handleDeletePole(pole.poleId)}
                                  >
                                    <Trash2 className="w-4 h-4 mr-1" />
                                    Remove
                                  </Button>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </ScrollArea>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* LoRa Simulation Tab */}
            <TabsContent value="simulation" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Send className="w-5 h-5" />
                    LoRa ESP32 Message Simulator
                  </CardTitle>
                  <CardDescription>
                    Simulate LoRa messages from ESP32 devices for testing
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Pole Selection */}
                  <div className="space-y-2">
                    <Label>Select Pole</Label>
                    <Select value={selectedPole} onValueChange={setSelectedPole}>
                      <SelectTrigger>
                        <SelectValue placeholder="Choose a pole to simulate" />
                      </SelectTrigger>
                      <SelectContent>
                        {poles.map((pole) => (
                          <SelectItem key={pole.id} value={pole.poleId}>
                            {pole.poleId} - {pole.location}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Message Type Buttons */}
                  <div className="space-y-3">
                    <Label>Simulate Message Type</Label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <Button
                        onClick={() => handleSimulateMessage('heartbeat')}
                        variant="outline"
                        className="h-20 flex flex-col items-center justify-center gap-2"
                      >
                        <RefreshCw className="w-6 h-6" />
                        <span>Heartbeat</span>
                        <span className="text-xs text-muted-foreground">Regular status update</span>
                      </Button>

                      <Button
                        onClick={() => handleSimulateMessage('emergency')}
                        variant="outline"
                        className="h-20 flex flex-col items-center justify-center gap-2 border-emergency text-emergency hover:bg-emergency hover:text-emergency-foreground"
                      >
                        <Activity className="w-6 h-6" />
                        <span>Emergency</span>
                        <span className="text-xs">Panic button pressed</span>
                      </Button>

                      <Button
                        onClick={() => handleSimulateMessage('status')}
                        variant="outline"
                        className="h-20 flex flex-col items-center justify-center gap-2"
                      >
                        <Signal className="w-6 h-6" />
                        <span>Status Update</span>
                        <span className="text-xs text-muted-foreground">Battery/signal info</span>
                      </Button>

                      <Button
                        onClick={() => handleSimulateMessage('test')}
                        variant="outline"
                        className="h-20 flex flex-col items-center justify-center gap-2"
                      >
                        <Send className="w-6 h-6" />
                        <span>Test Message</span>
                        <span className="text-xs text-muted-foreground">Connection test</span>
                      </Button>
                    </div>
                  </div>

                  {/* Gateway Info */}
                  {gateways.length > 0 && (
                    <Card className="bg-muted/50">
                      <CardContent className="p-4">
                        <h4 className="font-semibold mb-2">Active Gateway</h4>
                        <div className="space-y-1 text-sm">
                          <p><span className="font-medium">ID:</span> {gateways[0].gatewayId}</p>
                          <p><span className="font-medium">Location:</span> {gateways[0].location}</p>
                          <p><span className="font-medium">Connected Poles:</span> {gateways[0].connectedPoles}</p>
                          <p><span className="font-medium">Signal Range:</span> {gateways[0].signalRange}m</p>
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Message Logs Tab */}
            <TabsContent value="messages" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Radio className="w-5 h-5" />
                    LoRa Message Logs
                  </CardTitle>
                  <CardDescription>
                    Real-time LoRa communication logs (Last 100 messages)
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[600px]">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Timestamp</TableHead>
                          <TableHead>Pole ID</TableHead>
                          <TableHead>Type</TableHead>
                          <TableHead>Payload</TableHead>
                          <TableHead>RSSI</TableHead>
                          <TableHead>SNR</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {messages.slice().reverse().map((msg) => (
                          <TableRow key={msg.id}>
                            <TableCell className="text-xs">
                              {new Date(msg.timestamp).toLocaleString()}
                            </TableCell>
                            <TableCell className="font-mono text-sm">{msg.poleId}</TableCell>
                            <TableCell>
                              <Badge variant={msg.messageType === 'emergency' ? 'destructive' : 'outline'}>
                                {msg.messageType}
                              </Badge>
                            </TableCell>
                            <TableCell className="font-mono text-xs">{msg.payload}</TableCell>
                            <TableCell className="text-sm">{msg.rssi.toFixed(1)} dBm</TableCell>
                            <TableCell className="text-sm">{msg.snr.toFixed(1)} dB</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </ScrollArea>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  );
}
