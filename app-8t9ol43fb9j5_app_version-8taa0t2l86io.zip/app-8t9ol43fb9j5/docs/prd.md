# Women Safety System Requirements Document
\n## 1. Application Overview\n
### 1.1 Application Name
Women Safety System

### 1.2 Application Description
A responsive web application designed for women safety in zero-network zones, featuring three separate interfaces: User Interface (Smart Safety Pole Simulation), Gateway Interface (LoRa ESP32 Gateway Operations), and Admin Interface (Control Center Dashboard). The system provides emergency alert functionality with offline capability using LoRa technology simulation.

### 1.3 Application Type
Web Application (Triple Interface System)

## 2. Core Functionality
\n### 2.1 User Interface - Smart Safety Pole Simulation

#### 2.1.1 Emergency Alert Button\n- Large red panic/SOS button with long-press functionality (3 seconds)
- Visual feedback:\n  - Screen background turns red\n  - Display message: Emergency Alert Triggered
  - Optional alert sound playback
- Automatic alert data transmission to Gateway Interface
- Alert data includes: Pole ID, timestamp, location information

#### 2.1.2 Push-to-Talk (PTT) Button
- Enabled only after panic button is triggered
- Button label: Push to Talk
- On press:\n  - Display Voice Channel Active status
  - Simulate voice transmission (text-based simulation)
  - Real-time communication channel with Admin Dashboard

#### 2.1.3 Status Indicators
- Network Status: Display Offline Mode (LoRa Simulated)
- Pole ID: Static or auto-generated identifier\n- Real-time timestamp display\n
#### 2.1.4 Interface Layout
- Header: Smart Safety Pole – Emergency Interface
- Main Content Area:\n  - Large panic/SOS button (prominent placement)
  - Push-to-Talk button (below panic button)
  - Status indicators panel
- Footer: Works without internet in real deployment

### 2.2 Gateway Interface - LoRa ESP32 Gateway Operations

#### 2.2.1 Emergency Information Reception
- Real-time emergency alert reception from Smart Safety Poles
- Display received data:
  - Pole ID\n  - Location coordinates or address
  - Timestamp of alert
  - Signal strength (RSSI simulation)
  - Alert status (Active/Resolved)
\n#### 2.2.2 Pole Location Registry
- Comprehensive list of all registered Smart Safety Poles
- Display information for each pole:
  - Pole ID (unique identifier)
  - Location details (coordinates or address)
  - Installation date
  - Last communication timestamp
  - Status (Online/Offline/Maintenance)
- Search and filter functionality by Pole ID or location

#### 2.2.3 LoRa ESP32 Simulation Dashboard
- Gateway status indicators:\n  - Gateway ID
  - Connection status
  - Number of connected poles
  - Data transmission rate
- LoRa network simulation metrics:
  - Signal quality indicators
  - Packet transmission success rate
  - Network coverage visualization

#### 2.2.4 Data Forwarding Control
- Manual/Automatic data forwarding toggle to Admin Dashboard
- Forwarding status indicator\n- Data packet log (sent/received)
\n#### 2.2.5 Interface Layout
- Header: LoRa ESP32 Gateway Operations Center
- Main Content Area:
  - Emergency alerts reception panel (top section)
  - Pole location registry table (middle section)
  - LoRa simulation dashboard (side panel)
  - Data forwarding control panel (bottom section)

### 2.3 Admin Interface - Control Center Dashboard

#### 2.3.1 Real-Time Alert Panel
- Live alert list displaying:
  - Pole ID
  - Location (text-based or dummy map)
  - Timestamp
  - Severity level (High/Medium/Low)\n- Visual priority indicators:
  - High Priority: Red highlight for immediate action
  - Medium Priority: Yellow/orange for verification required
  - Low Priority: Gray for logged only

#### 2.3.2 Alert Aggregation System
- Zone-based alert grouping
- Alert count display per zone (e.g., 3 Alerts in Zone A)
- Multiple alert handling logic\n
#### 2.3.3 Push-to-Talk Control
- Button: Enable Voice Communication
- Status indicator: Connected/Disconnected
- Real-time voice channel management
\n#### 2.3.4 Response Action Buttons
- Notify Police button
- Notify Campus Security button
- Mark as Resolved button
- Each action updates alert status and syncs with Gateway Interface

#### 2.3.5 Alert History Logs
- Timestamped alert history
- Previous alerts storage\n- Searchable log entries\n
#### 2.3.6 Gateway Connection Status
- Display connection status with Gateway Interface
- Data reception indicator
- Last sync timestamp

#### 2.3.7 Interface Layout\n- Header: Women Safety Control Center Dashboard
- Main Content Area:\n  - Gateway connection status (top banner)
  - Alert panel (main section)
  - Alert aggregation section
  - Push-to-Talk control panel
  - Action buttons row
  - Logs section (bottom)

## 3. Technical Requirements

### 3.1 Real-Time Synchronization
- Panic button click on User Interface instantly reflects on Gateway Interface
- Gateway Interface forwards emergency data to Admin Dashboard
- Push-to-Talk activation synchronized across all interfaces
- Use browser local storage, WebSocket simulation, or JavaScript events
- No backend required for demo functionality

### 3.2 Data Management
- Browser local storage for alert persistence and pole registry
- Alert history logging and retrieval
- Pole location database management
- Session-based data handling
\n### 3.3 Code Implementation
- Simple HTML, CSS, and JavaScript (React optional)
- Clear code comments for explanation
- Demo-ready implementation
- Local browser execution capability
- Separate files for User, Gateway, and Admin interfaces
\n## 4. Design Requirements\n
### 4.1 User Interface Design
- Clean, minimal design
- Large, easily accessible buttons
- Mobile-first responsive layout
- High contrast for emergency elements (red for panic, clear status indicators)
- Simple navigation

### 4.2 Gateway Interface Design
- Technical dashboard appearance
- Data-focused layout with tables and metrics
- Clear visualization of LoRa network simulation\n- Professional monitoring interface style
- Desktop-optimized layout

### 4.3 Admin Interface Design
- Desktop-friendly layout
- Professional control-room appearance
- Clear alert visibility with color-coded priorities
- Organized information hierarchy
- Enhanced working functionality with gateway integration

### 4.4 General Design Principles
- Simple and functional\n- High contrast for critical information\n- No unnecessary animations
- Hackathon and demo-ready presentation
- Professional appearance

## 5. Page Structure

### 5.1 User Interface Page (Smart Safety Pole)
- Header Section\n- Main Content:
  - Panic/SOS Button (large, red, prominent)
  - Push-to-Talk Button (enabled after panic trigger)
  - Status Indicators Panel (network status, pole ID, timestamp)
- Footer Section

### 5.2 Gateway Interface Page (LoRa ESP32 Gateway)
- Header Section
- Main Dashboard:
  - Emergency Alerts Reception Panel
  - Pole Location Registry Table
  - LoRa Simulation Dashboard (side panel)
  - Data Forwarding Control Panel
\n### 5.3 Admin Interface Page (Control Center)
- Header Section
- Main Dashboard:\n  - Gateway Connection Status Banner
  - Real-time Alert Panel
  - Alert Aggregation Section
  - Push-to-Talk Control Panel
  - Action Buttons Row
  - Alert History Logs Section

## 6. Functional Workflow
\n### 6.1 Emergency Alert Flow
1. User long-presses panic button (3 seconds) on User Interface
2. Screen turns red with alert message\n3. Alert data sent to Gateway Interface
4. Gateway Interface receives and logs emergency information (Pole ID, location, timestamp)
5. Gateway forwards alert to Admin Dashboard
6. Admin Dashboard displays new alert with priority level
7. Push-to-Talk button enabled on User Interface
8. Admin can respond via action buttons
9. Response actions sync back to Gateway Interface

### 6.2 Push-to-Talk Flow
1. User presses PTT button (after panic trigger)
2. Voice Channel Active status displayed
3. Signal routed through Gateway Interface
4. Admin Dashboard shows voice communication active
5. Admin enables voice communication from control panel
6. Two-way communication channel simulated

### 6.3 Gateway Operations Flow
1. Gateway Interface maintains registry of all Smart Safety Poles
2. Each pole entry includes Pole ID and location information
3. Gateway monitors connection status of all poles
4. Emergency alerts received and displayed in real-time
5. Gateway forwards data to Admin Dashboard
6. Admin actions are logged and synced back to Gateway\n
## 7. Deliverables
- Complete working code with HTML, CSS, and JavaScript
- Separate User Interface page file
- Separate Gateway Interface page file
- Separate Admin Interface page file
- Clear code documentation
- Easy-to-explain demo functionality for LoRa ESP32 simulation\n- Local browser execution ready
- Enhanced admin page with working gateway integration